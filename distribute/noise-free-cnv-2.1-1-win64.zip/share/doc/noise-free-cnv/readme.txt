noise-free-cnv is a program for analyzing and manipulating DNA microarray data.

The noise-free-cnv program package has been specifically developed to analyze
DNA microarray data for copy number variation and to manipulate such datasets
in order to reduce noise.

The central program of the noise-free-cnv package is noise-free-cnv-gtk, a
visual editor for interactive visualization and manipulation of DNA microarray
data. Besides functioning as a browser for direct inspection and verification
of alleged CNV findings, it allows the user to perform many operations on the
data to separate and eliminate noise components. 

As a second program, noiser-free-cnv-filter implements a specific algorithm for
system noise reduction of DNA microarray data. It is usable as a command line
program to be easily applied to a batch of datasets.

Both programs are able to read and write files suitable for PennCNV.


homepage:	http://noise-free-cnv.sourceforge.net
author:		Philip Ginsbach <philip.development@googlemail.com>
